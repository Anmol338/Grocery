@extends('layouts.auth')

@section('content')
    <div class="card card-md">
        <div class="card-body">
            <h2 class="h2 text-center mb-4">
                Login
            </h2>
            <form action="{{ route('login') }}" method="POST" autocomplete="off">
                @csrf
                <div class="mb-3">
                    <label for="email" class="form-label">
                        Username
                    </label>
                    <input type="email" name="email" id="email"
                        class="form-control @error('email') is-invalid @enderror" placeholder="Username" autocomplete="off"
                        value="{{ old('email') }}">

                    @error('email')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">
                        Password
                    </label>

                    <div class="input-group input-group-flat">
                        <input type="password" name="password" id="password"
                            class="form-control @error('password') is-invalid @enderror" placeholder="Password"
                            autocomplete="off">

                        @error('password')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                </div>

                <div class="mb-2 d-flex justify-content-around">
                    <label for="remember" class="form-check">
                        <input type="checkbox" id="remember" name="remember" class="form-check-input" />
                        <span class="form-check-label">Remember me on this device</span>
                    </label>
                    <span class="form-label-description">
                        <a href="{{ route('password.request') }}">Forgot password?</a>
                    </span>
                </div>

                <div class="form-footer">
                    <button type="submit" class="btn btn-danger w-100">
                        Sign in
                    </button>

                    <div class="text-end text-secondary mt-3">
                        Don't have account yet? <a href="{{ route('register') }}" tabindex="-1">
                            Sign up
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

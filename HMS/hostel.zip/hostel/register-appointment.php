<?php
session_start();
include('includes/config.php');
date_default_timezone_set('Asia/Kathmandu');
include('includes/checklogin.php');
check_login();
$aid = $_SESSION['id'];

if (isset($_POST['submit'])) {
	// Posted Values
	$appointmenttype = $_POST['atype'];
	$description = $_POST['desc'];
	$appointmentdate = $_POST['adate'];
	$appointmenttime = $_POST['atime'];
	$anumber = mt_rand(100000000, 999999999);

	// Query for insertion data into database
	$query = "insert into  appointment(appointmentId,userid,appointmenttype,description,appointmentdate,appointmenttime) values(?,?,?,?,?,?)";
	$stmt = $mysqli->prepare($query);
	$rc = $stmt->bind_param('iissss', $anumber, $aid, $appointmenttype, $description, $appointmentdate, $appointmenttime);
	$stmt->execute();

	echo "<script>alert('Appoinment Booked. Appoinment number is :  is: $anumber');</script>";
	echo "<script type='text/javascript'> document.location = 'my-complaints.php'; </script>";
}



?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Complaint Registration</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
	<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
	<script type="text/javascript" src="js/validation.min.js"></script>
	<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>

</head>

<body>
	<?php include('includes/header.php'); ?>
	<div class="ts-main-content">
		<?php include('includes/sidebar.php'); ?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
						<h2 class="page-title">Book Appointment</h2>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-body">
										<form method="post" action="" name="complaint" class="form-horizontal" enctype="multipart/form-data">
											<div class="form-group">
												<label class="col-sm-2 control-label"> Appointment Type </label>
												<div class="col-sm-8">
													<select class="form-control" required="required" name="atype">
														<option value="">Select Complaint Type</option>
														<option value="Hostel Visit">Hostel Visit</option>
														<option value="Other">Other</option>
													</select>
												</div>
											</div>


											<div class="form-group">
												<label class="col-sm-2 control-label">Description</label>
												<div class="col-sm-8">
													<textarea name="desc" id="desc" class="form-control"></textarea>
												</div>
											</div>

											<div class="form-group">
												<label class="col-sm-2 control-label">Appointment Date</label>
												<div class="col-sm-8">
													<input type="date" name="adate" id="adate" class="form-control">
												</div>
											</div>

											<div class="form-group">
												<label class="col-sm-2 control-label">Appointment Time</label>
												<div class="col-sm-8">
													<input type="time" name="atime" id="atime" class="form-control">
												</div>
											</div>

											<div class="col-sm-6 col-sm-offset-4">

												<input type="submit" name="submit" Value="Submit" class="btn btn-primary">
											</div>
										</form>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>
<script type="text/javascript">
	$(document).ready(function() {
		$('input[type="checkbox"]').click(function() {
			if ($(this).prop("checked") == true) {
				$('#paddress').val($('#address').val());
				$('#pcity').val($('#city').val());
				$('#pstate').val($('#state').val());
				$('#ppincode').val($('#pincode').val());
			}

		});
	});
</script>
<script>
	function checkAvailability() {

		$("#loaderIcon").show();
		jQuery.ajax({
			url: "check_availability.php",
			data: 'emailid=' + $("#email").val(),
			type: "POST",
			success: function(data) {
				$("#user-availability-status").html(data);
				$("#loaderIcon").hide();
			},
			error: function() {}
		});
	}
</script>

</html>
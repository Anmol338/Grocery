composer update
composer install

npm install
npm audit fix --force
npm audit fix
npm run dev

php artisan migrate
php artisan db:seed
php artisan key:generate
php artisan serve

---Admin Login Details---

Email   : admin@mail.com
Password: codeastro.com
<div>
    <x-virtual-select
        id="supplier_id" wire:model="selectedSupplier" options="suppliers"
    />

    {{---
    <input id="supplier_id" type="text" wire:model="selectedSupplier">
    ---}}
</div>

Login Details for admin :
Username: admin
Password: Test@1234
Login Details for user:
Username: test@gmail.com
Password: Test@123
<!DOCTYPE html>
<html>
<head>
    <title><?php echo e(__('Stock alert')); ?></title>
</head>
<body>
    <p><?php echo e('The following products are gonna out of stock: '); ?></p>
    <?php $__currentLoopData = $listProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e(__('Product Name: ' . $product->name )); ?><p>
        <p><?php echo e(__('Current Stock: ' . $product->quantity )); ?><p>
        <p><?php echo e(__('Alert If Below: ' . $product->quantity_alert )); ?><p>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH D:\PHP\IMS_GIT\inventory-management-system\resources\views/emails/stock-alert.blade.php ENDPATH**/ ?>